<?php
/**
 * MultiPolygon: A collection of Polygons
 */
class MultiPolygon extends getPHP_Collection
{
  protected $geom_type = 'MultiPolygon';
}
