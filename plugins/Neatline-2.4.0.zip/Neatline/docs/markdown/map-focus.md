## Default Focus

The default lon/lat focus position that the map "snaps" to when the record is selected. It's easiest to set this field by moving the map to the location you want and clicking the "Use Current Viewport as Default" button (see below).
